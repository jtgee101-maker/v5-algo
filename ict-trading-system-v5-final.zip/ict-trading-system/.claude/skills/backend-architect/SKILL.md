---
name: backend-architect
description: "Build and refactor the FastAPI backend, database layer, services, schemas, and repositories. Use this skill whenever working on: API routers, Pydantic schemas, SQLAlchemy models, service classes, repository patterns, database migrations, dependency injection, or any backend infrastructure. Also trigger when adding new endpoints, refactoring existing services, or debugging API issues."
---

# Backend Architect Skill

## Purpose
Build, maintain, and refactor the ICT Trade Mission Control FastAPI backend.

## Allowed Scope
- `backend/api/routers.py` — API route handlers
- `backend/schemas/api.py` — Pydantic request/response models
- `backend/services/` — business logic services
- `backend/db/models.py` — SQLAlchemy ORM models
- `backend/db/repositories/` — data access layer
- `backend/db/session.py` — engine and session management
- `backend/dependencies.py` — FastAPI DI
- `backend/auth.py` — authentication middleware
- `backend/settings.py` — configuration
- `backend/app.py` — application factory
- `scripts/run_api.py` — API runner
- `scripts/bootstrap_demo_data.py` — seed data
- `tests/backend/` — all backend tests

## Forbidden Actions
- Do NOT modify `core/risk/engine.py` risk parameters
- Do NOT change risk ladder thresholds in `config/risk.yaml`
- Do NOT remove or weaken auth checks
- Do NOT enable live mode by default
- Do NOT bypass the approval workflow
- Do NOT modify trading strategy logic (that's strategy-builder's domain)

## Architecture Rules
1. **Service/Repository pattern**: Routers call services, services call repositories. No DB queries in routers.
2. **Pydantic everywhere**: All request/response models in `backend/schemas/api.py`. No raw dicts in router responses.
3. **Async-first**: All DB operations use async SQLAlchemy sessions.
4. **Clean DI**: Services get DB sessions via FastAPI `Depends(get_db)`. ConfigService is the only singleton.
5. **Auth enforcement**: Admin-only endpoints use `require_admin()`. Operator endpoints use `require_operator()`. Read endpoints are open to all authenticated roles.
6. **Audit trail**: Every state-changing action (approve, reject, config change, mode change, kill switch) must persist a record.

## Required Inputs
- Which endpoint or service to build/modify
- The Pydantic schema for request/response
- Which DB tables are involved
- Auth role requirement

## Expected Outputs
- Working endpoint with proper auth
- Pydantic models for request/response
- Service method with business logic
- Repository query if needed
- Test covering success and error paths

## Test Requirements
- Every new endpoint needs at least:
  - Success case test
  - Auth rejection test (if protected)
  - 404/400 edge case test
- Use `TestClient` with in-memory SQLite
- Reset config service singleton between tests

## Example Prompts
- "Add a GET /api/reconciliation-status endpoint that shows last recon result"
- "Refactor the signal approval flow to support batch approve"
- "Add pagination to the trades endpoint with cursor-based paging"
- "Add a POST /api/incidents/{id}/resolve endpoint"
