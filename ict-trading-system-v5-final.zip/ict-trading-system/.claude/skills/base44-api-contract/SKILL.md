---
name: base44-api-contract
description: "Maintain the API contract between the FastAPI backend and Base44 frontend. Use this skill when adding or changing API endpoints, modifying response schemas, updating the frontend integration spec, or verifying contract compatibility. Also trigger when Base44 reports data format issues or when a backend change might break the frontend."
---

# Base44 API Contract Skill

## Purpose
Keep the API contract between backend and frontend stable. Any backend change that affects response shapes must be documented here and communicated to Base44.

## Allowed Scope
- `backend/schemas/api.py` — response models (changes require contract review)
- `backend/api/routers.py` — endpoint signatures
- This SKILL.md — contract documentation

## Forbidden Actions
- Do NOT remove fields from existing response models (breaking change)
- Do NOT rename endpoints without updating this contract
- Do NOT change field types in responses (e.g., float→string)
- Adding new optional fields is safe. Removing or changing existing fields is NOT.

## Current API Contract (v0.4.0)

### Read Endpoints (all roles)

| Endpoint | Method | Response Model |
|---|---|---|
| `/api/health` | GET | `HealthResponse` |
| `/api/account-state` | GET | `AccountStateResponse` |
| `/api/market-state?symbol=&limit=` | GET | `ItemsResponse[MarketStateOut]` |
| `/api/signals?status=&symbol=&limit=` | GET | `ItemsResponse[SignalOut]` |
| `/api/trades?symbol=&status=&limit=` | GET | `ItemsResponse[TradeOut]` |
| `/api/risk-events?limit=` | GET | `ItemsResponse[RiskEventOut]` |
| `/api/incidents?status=&limit=` | GET | `ItemsResponse[IncidentOut]` |
| `/api/config` | GET | `ConfigResponse` |
| `/api/journals?limit=` | GET | `ItemsResponse[JournalOut]` |
| `/api/agents/runs?limit=` | GET | `ItemsResponse[AgentRunOut]` |
| `/api/metrics/overview` | GET | `dict` (see below) |
| `/api/metrics/strategies` | GET | `{"strategies": [...]}` |
| `/api/metrics/sessions` | GET | `{"sessions": [...]}` |
| `/api/reconciliation-status` | GET | `ReconciliationStatusResponse` |

### Write Endpoints (role-restricted)

| Endpoint | Method | Auth | Request | Response |
|---|---|---|---|---|
| `/api/approve-signal` | POST | operator+ | `ApproveSignalRequest` | `ApprovalResponse` |
| `/api/reject-signal` | POST | operator+ | `RejectSignalRequest` | `ApprovalResponse` |
| `/api/update-config` | POST | admin | `UpdateConfigRequest` | `UpdateConfigResponse` |
| `/api/kill-switch` | POST | admin | `KillSwitchRequest` | `KillSwitchResponse` |
| `/api/set-mode` | POST | admin | `SetModeRequest` | `SetModeResponse` |

### Key Response Shapes

**ItemsResponse**: `{ "items": [...] }` — all list endpoints use this wrapper.

**SignalOut.status** values: `pending`, `approved`, `rejected`, `expired`, `executed`

**IncidentOut.severity** values: `low`, `medium`, `high`, `critical`

**IncidentOut.status** values: `open`, `investigating`, `resolved`

**ConfigResponse.mode** values: `shadow`, `demo`, `live`

### Metrics Overview Shape
```json
{
  "total_trades": 0,
  "open_trades": 0,
  "winners": 0,
  "losers": 0,
  "win_rate": 0.0,
  "total_pnl": 0.0,
  "gross_profit": 0.0,
  "gross_loss": 0.0,
  "avg_win": 0.0,
  "avg_loss": 0.0,
  "profit_factor": 0.0,
  "expectancy": 0.0,
  "max_drawdown": 0.0,
  "total_signals": 0,
  "signal_status": {},
  "rejection_rate": 0.0,
  "expiration_rate": 0.0,
  "approval_rate": 0.0
}
```

## Base44 Integration Notes

### Data Mode
Base44 should support `DATA_MODE = mock | api`:
- `mock`: uses seeded entity data (for preview/demo)
- `api`: calls backend endpoints via `BACKEND_BASE_URL`

### Polling
- Health: every 30s
- Account state: every 30s
- Signals: every 10s (active queue)
- Market state: every 30s
- Trades: every 60s
- Incidents: every 30s
- Metrics: every 120s

### Auth Header
When `DATA_MODE=api`, include `X-API-Key: <API_TOKEN>` in all requests.

### Error Handling
- On 401: show "Authentication failed" banner
- On 5xx: show "Backend unavailable" banner + last sync time
- On timeout: show "Connection slow" warning
- On success: update last sync timestamp

## Contract Change Process
1. Backend developer proposes change
2. Update this SKILL.md with the new shape
3. Add backwards-compatible fields (new optional fields OK)
4. If breaking change required: bump contract version, coordinate with Base44
5. Add test verifying the response shape matches this contract
