---
name: risk-auditor
description: "Review risk gate decisions, drawdown behavior, throttle effectiveness, and exposure compliance. Use this skill when auditing risk events, analyzing rejection patterns, checking throttle transitions, reviewing position sizing accuracy, or investigating risk anomalies. Also trigger when the self-improver flags risk-related issues."
---

# Risk Auditor Skill

## Purpose
Audit the risk engine's decisions for correctness and identify patterns that suggest misconfiguration or degradation. This is a review-only skill — it does NOT modify risk parameters.

## Allowed Scope
- `core/risk/engine.py` — read and audit (not modify)
- `core/agents/risk_auditor_agent.py` — auditor logic
- `backend/services/metrics_service.py` — metrics queries
- `config/risk.yaml` — read only for reference
- `tests/test_risk_engine.py` — adding new audit tests

## Forbidden Actions
- Do NOT change values in `config/risk.yaml`
- Do NOT modify the risk engine's evaluate() logic
- Do NOT change throttle levels or drawdown thresholds
- Do NOT bypass any risk gate check
- Do NOT auto-apply audit recommendations

## What to Audit

### Rejection Analysis
- Count rejections by reason code
- Flag if one reason dominates (>50% of rejections)
- Check if rejections correlate with time of day or symbol

### Throttle Behavior
- Verify throttle activated at correct drawdown levels
- Check that risk reduction matches config
- Verify hard lock fires at 18%

### Position Sizing
- Compare intended risk% vs actual risk%
- Check if sizing respects min/max lot constraints
- Verify throttle-adjusted sizing is correct

### Exposure Compliance
- Total open risk never exceeds max_simultaneous_risk
- Correlated basket risk stays within limits
- Per-symbol risk stays within limits

### Signal-to-Outcome Quality
- Do approved high-confidence signals actually win more?
- Is the confidence calibrated (80% confidence ≈ 80% win rate)?
- Are rejection reasons correlated with avoiding losers?

## Output Format
Audit results should be:
1. Persisted as `journal_entries` with `created_by="risk_auditor_agent"`
2. Tagged with `["risk_audit", "findings"]` or `["risk_audit", "clean"]`
3. Include specific findings and recommendations

## Test Requirements
- Test: auditor detects recurring rejection pattern
- Test: auditor flags high expiration rate
- Test: auditor handles empty data gracefully
- Test: audit results are persisted

## Example Prompts
- "Run a risk audit on the last 100 signals"
- "Check if the 5% drawdown throttle actually reduced position sizes"
- "Analyze which rejection reasons correlate with avoided losses"
