---
name: reconciliation-guard
description: "Compare local database state against broker positions and orders to detect mismatches. Use this skill when building or maintaining reconciliation logic, debugging execution discrepancies, creating mismatch incidents, or implementing safe-mode recommendations. Also trigger when the monitor agent flags state differences."
---

# Reconciliation Guard Skill

## Purpose
Ensure the local database accurately reflects broker reality. Detect and escalate any mismatches before they cause harm.

## Allowed Scope
- `scripts/reconcile_broker_state.py` — reconciliation script
- `backend/api/routers.py` — reconciliation status endpoint
- `backend/services/` — reconciliation service if created
- `backend/db/models.py` — incident records
- `core/execution/client.py` — broker API calls (read only)
- `tests/backend/` — reconciliation tests

## Forbidden Actions
- Do NOT auto-close broker positions without human approval
- Do NOT auto-modify local DB records to match broker (flag, don't fix)
- Do NOT suppress or ignore mismatches
- Do NOT disable safe-mode recommendations

## What to Reconcile

### Level 1: Position Count
- Local DB open trades count vs broker open positions count
- Mismatch → incident (severity: high)

### Level 2: Position Details
- For each local open trade, find matching broker position by instrument
- Compare: quantity, direction, entry price
- Any difference → incident with details

### Level 3: Order State
- Local sent orders should have corresponding broker orders or positions
- Orphaned local orders (sent but no broker match) → incident (severity: warning)
- Unknown broker positions (not in local DB) → incident (severity: high)

### Level 4: P&L Consistency
- Local P&L calculations vs broker-reported P&L
- Drift > 2% → incident (severity: warning)

## Escalation Rules
| Mismatch Type | Severity | Action |
|---|---|---|
| Missing broker position | high | Incident + recommend safe mode |
| Unknown broker position | high | Incident + recommend safe mode |
| Quantity mismatch | high | Incident + recommend investigation |
| Orphaned local order | warning | Incident |
| P&L drift | warning | Incident |
| Connection failure | critical | Incident + recommend safe mode |

## Safe Mode Recommendation
When ≥1 high-severity mismatch is found:
1. Create a critical incident titled "Reconciliation recommends safe mode"
2. Include mismatch count and details
3. Pipeline should check for this incident and optionally freeze new trades

## API Endpoint
`GET /api/reconciliation-status` should return:
```json
{
  "last_run": "2026-03-12T15:00:00Z",
  "status": "clean" | "mismatches_found" | "never_run",
  "mismatches": 0,
  "details": []
}
```

## Test Requirements
- Test: clean reconciliation with matching state
- Test: mismatch detected when local has trade but broker doesn't
- Test: mismatch detected when broker has position not in local DB
- Test: incident created on mismatch
- Test: safe mode recommended on high-severity mismatch
- Test: connection failure handled gracefully

## Example Prompts
- "Run reconciliation and show me the results"
- "Add a scheduled reconciliation check every 5 minutes during session"
- "The reconciliation found a quantity mismatch — investigate"
