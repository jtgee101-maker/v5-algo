---
name: strategy-builder
description: "Add, modify, and test trading strategies. Use this skill whenever working on: new strategy implementations, strategy parameter tuning, confidence scoring, confluence tag logic, entry/stop/target calculations, or strategy engine registration. Also trigger when reviewing strategy test results or debugging signal generation."
---

# Strategy Builder Skill

## Purpose
Implement rule-based trading strategies that consume MarketState and produce TradeSignal objects. Every strategy must be testable, versioned, and follow the same structural pattern.

## Allowed Scope
- `core/strategy/*.py` — strategy implementations
- `core/strategy/engine.py` — strategy registration
- `core/strategy/scorer.py` — confidence scoring
- `config/strategy.yaml` — strategy parameters
- `tests/test_strategies.py` — strategy tests

## Forbidden Actions
- Do NOT use LLM discretion at runtime (pure rule-based only)
- Do NOT modify risk parameters or risk engine
- Do NOT auto-deploy strategies to live execution
- Do NOT change the TradeSignal schema without updating all consumers
- Do NOT hardcode prices, thresholds, or magic numbers (use config)
- Do NOT create strategies that can bypass the risk gate

## Strategy Pattern (mandatory for every strategy)

Every strategy class MUST have:

```python
class MyStrategy:
    def __init__(self, config_path: str = "config/strategy.yaml"):
        # Load config, set self.strategy_id, self.min_rr, self.min_confidence

    def evaluate(self, state: MarketState) -> Optional[TradeSignal]:
        # Gate 1: Session check
        # Gate 2: Required structure check
        # Gate 3: Specific pattern check
        # Gate 4: Confirmation check
        # Gate 5: Entry calculation
        # Gate 6: Stop calculation
        # Gate 7: Target ladder
        # Gate 8: R:R check (>= min_reward_risk)
        # Gate 9: Confidence score (>= min_confidence)
        # Return TradeSignal or None
```

## TradeSignal Requirements
Every signal MUST include:
- `strategy_id` — format: `strategy_name_vN`
- `symbol`, `direction`, `entry_price`, `stop_price`
- `targets` — list of Target objects with price + pct_close
- `confidence` — 0.0–1.0 from scorer
- `confidence_breakdown` — 7-dimension breakdown
- `confluence_tags` — list of strings describing what confirms the setup
- `invalidation` — string describing what would invalidate the trade
- `reward_risk` — calculated R:R ratio
- `regime` — market regime classification
- `session` — which session the signal was generated in

## V1 Strategy Family
1. **ny_sweep_reversal** — reversal after manipulation sweep, confirmed by SMT/PO3
2. **ny_continuation** — trend continuation after sweep + pullback into FVG
3. **psych_level_model** — precision entries at round numbers with ≥3 confluence

## Config Requirements
Every strategy must have a config block in `config/strategy.yaml`:
```yaml
my_strategy:
  version: v1
  status: active  # active | shadow | deprecated
  symbols: [NAS100, US30, EURUSD, BTCUSD]
  session: ny_killzone
  min_reward_risk: 2.0
  min_confidence: 0.65
  rules: { ... }
  confidence_boosters: { ... }
```

## Test Requirements
For each strategy, test:
- Rejects when session is wrong
- Rejects when key structure is missing
- Rejects when R:R is below threshold
- Rejects when confidence is below threshold
- Generates valid signal when all conditions met
- Signal has correct strategy_id, direction, and tags
- Strategy engine loads it when config status=active

## Example Prompts
- "Implement ny_continuation.py following the strategy pattern"
- "The sweep reversal is generating signals with R:R below 1.5 — find and fix"
- "Add a new confidence booster for volume spike detection"
