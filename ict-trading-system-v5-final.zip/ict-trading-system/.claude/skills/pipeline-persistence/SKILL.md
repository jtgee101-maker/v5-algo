---
name: pipeline-persistence
description: "Wire the trading pipeline to the database and approval workflow. Use this skill whenever working on: pipeline-to-DB persistence, signal status transitions, approval-aware execution, account state syncing, market state persistence, trade result recording, or any integration between core/pipeline.py and the backend services. Also trigger when debugging status transition bugs or data flow issues."
---

# Pipeline Persistence Skill

## Purpose
Ensure the trading pipeline writes everything to the database and respects the approval workflow. DB is source of truth. JSON artifacts are secondary.

## Allowed Scope
- `core/pipeline.py` — main trading loop
- `backend/services/pipeline_persistence.py` — DB bridge service
- `backend/services/signal_service.py` — signal lifecycle
- `backend/db/models.py` — if new fields needed
- `tests/backend/test_approval_flow.py` — approval tests

## Forbidden Actions
- Do NOT skip DB persistence (every market state, signal, order, and result must be saved)
- Do NOT allow execution of non-approved signals when `manual_approval_required=true`
- Do NOT remove the expiration mechanism for stale pending signals
- Do NOT change risk engine behavior
- Do NOT enable live mode execution

## Signal Status Transitions (strict)
```
Pipeline generates signal
    ↓
Risk engine evaluates
    ↓
risk_approved=false → status="rejected" (terminal)
risk_approved=true + manual_approval=true → status="pending"
risk_approved=true + manual_approval=false → status="approved"
    ↓
pending → operator approves → status="approved"
pending → operator rejects → status="rejected" (terminal)
pending → expires_at passes → status="expired" (terminal)
    ↓
approved → pipeline executes → status="executed" (terminal)
```

Terminal states (rejected, expired, executed) MUST NEVER transition back.

## Data Flow Per Pipeline Tick
1. `_sync_account_state()` → updates risk engine + persists to `accounts` table
2. `_process_symbol()` for each symbol:
   a. Fetch candles from broker
   b. Build MarketState → persist to `market_states`
   c. Strategy engine evaluates → signals
   d. Risk engine gates each signal
   e. Persist signal to `trade_signals` with correct status
   f. If approved + not shadow → execute via broker
   g. Persist `approved_orders` before sending
   h. Persist `trade_results` after broker response
3. `_expire_stale_signals()` → mark expired pending signals
4. `_execute_approved_signals()` → check DB for operator-approved signals

## Test Requirements
- Test: pending signal is NOT executed
- Test: approved signal IS executed in demo mode
- Test: rejected signal is NEVER executed
- Test: expired signal is NEVER executed
- Test: market state is persisted every tick
- Test: signal persistence includes correct status based on risk + approval mode
- Test: expiration sweep marks old pending signals

## Example Prompts
- "The pipeline is not persisting market states — debug and fix"
- "Add batch expiration for signals older than 30 minutes"
- "Wire the pipeline to also persist risk events when throttle activates"
