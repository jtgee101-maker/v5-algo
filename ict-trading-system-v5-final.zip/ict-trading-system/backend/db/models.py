"""SQLAlchemy ORM models for all persistence tables."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import (
    Column, Float, ForeignKey, Index, Integer, String, Text,
)
from sqlalchemy.orm import relationship

from backend.db.base import Base


def _uuid() -> str:
    return str(uuid4())


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Account(Base):
    __tablename__ = "accounts"

    id = Column(String, primary_key=True, default=_uuid)
    broker_name = Column(String, nullable=False)
    account_name = Column(String, nullable=False)
    account_type = Column(String, nullable=False)  # demo, live
    mode = Column(String, nullable=False, default="shadow")  # shadow, demo, live
    balance = Column(Float, nullable=False, default=0)
    equity = Column(Float, nullable=False, default=0)
    margin_used = Column(Float, nullable=False, default=0)
    free_margin = Column(Float, nullable=False, default=0)
    drawdown_pct = Column(Float, nullable=False, default=0)
    status = Column(String, nullable=False, default="disconnected")
    currency = Column(String, default="USD")
    updated_at = Column(String, nullable=False, default=_now_iso)


class MarketStateRecord(Base):
    __tablename__ = "market_states"
    __table_args__ = (
        Index("idx_market_states_symbol_ts", "symbol", "timestamp"),
    )

    id = Column(String, primary_key=True, default=_uuid)
    symbol = Column(String, nullable=False)
    timestamp = Column(String, nullable=False)
    session_name = Column(String)
    session_active = Column(Integer, nullable=False, default=0)
    overnight_range_high = Column(Float)
    overnight_range_low = Column(Float)
    prior_day_high = Column(Float)
    prior_day_low = Column(Float)
    asia_high = Column(Float)
    asia_low = Column(Float)
    weekly_high = Column(Float)
    weekly_low = Column(Float)
    psych_level_nearest = Column(Float)
    smt_flag = Column(Integer, nullable=False, default=0)
    po3_phase = Column(String)
    sweep_detected = Column(Integer, nullable=False, default=0)
    displacement_detected = Column(Integer, nullable=False, default=0)
    bias = Column(String)
    structure_score = Column(Float)
    json_payload = Column(Text, nullable=False, default="{}")


class TradeSignalRecord(Base):
    __tablename__ = "trade_signals"
    __table_args__ = (
        Index("idx_trade_signals_status_ts", "status", "timestamp"),
    )

    id = Column(String, primary_key=True, default=_uuid)
    symbol = Column(String, nullable=False)
    strategy_name = Column(String, nullable=False)
    strategy_version = Column(String)
    timestamp = Column(String, nullable=False)
    side = Column(String, nullable=False)  # buy, sell
    confidence = Column(Float, nullable=False)
    expected_value = Column(Float)
    entry_price = Column(Float, nullable=False)
    stop_price = Column(Float, nullable=False)
    take_profit_1 = Column(Float)
    take_profit_2 = Column(Float)
    take_profit_3 = Column(Float)
    invalidation_reason = Column(String)
    risk_score = Column(Float)
    structure_score = Column(Float)
    confluence_tags = Column(Text)  # JSON array as string
    status = Column(String, nullable=False, default="pending")
    expires_at = Column(String)
    approved_by = Column(String)
    approved_at = Column(String)
    rejected_by = Column(String)
    rejected_at = Column(String)
    rejection_reason = Column(String)
    json_payload = Column(Text, nullable=False, default="{}")

    approved_orders = relationship("ApprovedOrderRecord", back_populates="signal")


class ApprovedOrderRecord(Base):
    __tablename__ = "approved_orders"

    id = Column(String, primary_key=True, default=_uuid)
    signal_id = Column(String, ForeignKey("trade_signals.id"), nullable=False)
    account_id = Column(String, ForeignKey("accounts.id"), nullable=False)
    symbol = Column(String, nullable=False)
    side = Column(String, nullable=False)
    order_type = Column(String, nullable=False)
    entry_price = Column(Float, nullable=False)
    stop_price = Column(Float, nullable=False)
    take_profit = Column(Float)
    quantity = Column(Float, nullable=False)
    risk_pct = Column(Float, nullable=False)
    instrument_id = Column(String)
    broker_payload = Column(Text)
    status = Column(String, nullable=False, default="pending")
    created_at = Column(String, nullable=False, default=_now_iso)

    signal = relationship("TradeSignalRecord", back_populates="approved_orders")
    trade_results = relationship("TradeResultRecord", back_populates="approved_order")


class TradeResultRecord(Base):
    __tablename__ = "trade_results"
    __table_args__ = (
        Index("idx_trade_results_closed_at", "closed_at"),
    )

    id = Column(String, primary_key=True, default=_uuid)
    approved_order_id = Column(String, ForeignKey("approved_orders.id"), nullable=False)
    external_trade_id = Column(String)
    account_id = Column(String, ForeignKey("accounts.id"), nullable=False)
    symbol = Column(String, nullable=False)
    strategy_name = Column(String)
    status = Column(String, nullable=False)  # open, closed, cancelled
    entry_price = Column(Float)
    exit_price = Column(Float)
    stop_price = Column(Float)
    take_profit = Column(Float)
    quantity = Column(Float)
    pnl = Column(Float)
    pnl_pct = Column(Float)
    fees = Column(Float)
    slippage = Column(Float)
    opened_at = Column(String)
    closed_at = Column(String)
    execution_notes = Column(Text)
    json_payload = Column(Text)

    approved_order = relationship("ApprovedOrderRecord", back_populates="trade_results")


class RiskEventRecord(Base):
    __tablename__ = "risk_events"

    id = Column(String, primary_key=True, default=_uuid)
    account_id = Column(String, ForeignKey("accounts.id"), nullable=False)
    event_type = Column(String, nullable=False)
    severity = Column(String, nullable=False)  # info, warning, critical
    message = Column(String, nullable=False)
    triggered_at = Column(String, nullable=False, default=_now_iso)
    resolved_at = Column(String)
    auto_action_taken = Column(String)
    json_payload = Column(Text)


class IncidentRecord(Base):
    __tablename__ = "incidents"
    __table_args__ = (
        Index("idx_incidents_status_created", "status", "created_at"),
    )

    id = Column(String, primary_key=True, default=_uuid)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)
    severity = Column(String, nullable=False)  # low, medium, high, critical
    source = Column(String, nullable=False)
    status = Column(String, nullable=False, default="open")
    summary = Column(String, nullable=False)
    details = Column(Text)
    created_at = Column(String, nullable=False, default=_now_iso)
    resolved_at = Column(String)
    json_payload = Column(Text)


class ConfigChangeRecord(Base):
    __tablename__ = "config_changes"

    id = Column(String, primary_key=True, default=_uuid)
    config_type = Column(String, nullable=False)
    config_key = Column(String, nullable=False)
    old_value = Column(String)
    new_value = Column(String, nullable=False)
    changed_by = Column(String, nullable=False)
    reason = Column(String)
    created_at = Column(String, nullable=False, default=_now_iso)


class JournalEntryRecord(Base):
    __tablename__ = "journal_entries"

    id = Column(String, primary_key=True, default=_uuid)
    trade_result_id = Column(String, ForeignKey("trade_results.id"), nullable=True)
    strategy_name = Column(String)
    symbol = Column(String, nullable=False)
    session_name = Column(String)
    summary = Column(String, nullable=False)
    lesson = Column(String)
    tags = Column(Text)  # JSON array as string
    created_by = Column(String, nullable=False)
    created_at = Column(String, nullable=False, default=_now_iso)


class AgentRunRecord(Base):
    __tablename__ = "agent_runs"

    id = Column(String, primary_key=True, default=_uuid)
    agent_name = Column(String, nullable=False)
    run_type = Column(String, nullable=False)  # scheduled, manual, triggered
    status = Column(String, nullable=False, default="started")
    input_summary = Column(Text)
    output_summary = Column(Text)
    error_message = Column(Text)
    started_at = Column(String, nullable=False, default=_now_iso)
    completed_at = Column(String)
